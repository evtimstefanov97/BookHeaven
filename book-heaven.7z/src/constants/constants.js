export const APP_KEY = "kid_rk-5A9V7X";
export const APP_SECRET = "f3b6b4d6a4bb4e278448e8398ecb7c02";
export const BASE_URL = "https://baas.kinvey.com/";
export const GUEST_USRNM = "guest";
export const GUEST_PSSWRD = "guest";
export const ADMIN_ROLE = "a5375d55-e92c-4479-9d46-961dc7d97396";
