import React, { Component } from 'react';
import BookCard from './../book-card/BookCard';
import Loader from 'react-loader-spinner';
import { getAll, remove } from '../../../api/book-api';
import { Dialog, DialogActionsBar } from '@progress/kendo-react-dialogs';
import { NotificationContainer, NotificationManager } from 'react-notifications';

export default class BookList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false,
            currentIdForDeletion: '',
            books: [],
            collectionEmpty: false

        };
        this.toggleDialog = this.toggleDialog.bind(this);
        this.confirm = this.confirm.bind(this);
    }
    async componentDidMount() {
        const allBooks = await getAll();
        let data = await allBooks.body;

        this.setState({ books: data, collectionEmpty: data.length == 0 });
    }
    createNotification(type, message, title) {
        switch (type) {
            case 'success':
                NotificationManager.success('Success!', title);
                break;
            case 'error':
                NotificationManager.error(message, 'Error!', 5000, () => {
                    alert('callback');
                });
                break;
        }
    };
    render() {
        return (
            <div style={{ height: "1000px" }}>
                <NotificationContainer />
                {
                    this.state.books.length > 0 ?
                        <div >
                            {this.renderBookRows()}
                            {this.state.visible && <Dialog title={"Please confirm"} onClose={this.toggleDialog}>
                                <p style={{ margin: "25px", textAlign: "center" }}>Are you sure you want to delete this book?</p>
                                <DialogActionsBar>
                                    <button className="k-button" onClick={this.toggleDialog}>No</button>
                                    <button className="k-button" onClick={this.confirm}>Yes</button>
                                </DialogActionsBar>
                            </Dialog>}
                            <div style={{ height: "100%" }} />
                        </div>


                        :
                        this.state.collectionEmpty ?
                            <h1>No books found</h1>
                            :
                            <Loader
                                type="Rings"
                                color="#00BFFF"
                                height="180"
                                width="180"
                            />
                }
            </div >
        )
    }
    async confirm() {
        let newBooks = this.state.books.filter(book => book._id !== this.state.currentIdForDeletion);
        let deleteRes = await remove(this.state.currentIdForDeletion);
        let deleteData = await deleteRes.body;

        if (deleteRes.status > 399) {
            this.createNotification("error", deleteRes.body.description)
        } else {
            this.createNotification("success", "Book deletion")

            this.setState({
                visible: !this.state.visible,
                books: [].concat(newBooks),
                collectionEmpty: newBooks.length == 0
            });
        }


    }
    toggleDialog() {
        this.setState({
            visible: !this.state.visible
        });
    }
    renderBookRows() {
        let multipleBooks = this.combineRows();
        let separateElements = [];

        for (let i = 0; i < multipleBooks.length; i += 4) {
            let oneRow = [];
            oneRow.push(
                multipleBooks.slice(i, i + 4).map(item => {
                    return item;
                })
            )
            separateElements.push(<div className="row">{oneRow.map(book => {
                return book;
            })}</div>)
        }
        return separateElements;
    }
    combineRows() {
        let rows = [];
        for (let i = 0; i < this.state.books.length; i++) {
            let book = this.state.books[i];
            rows.push(<BookCard
                name={book.Title}
                author={book.Author}
                _id={book._id}
                key={book.id}
                rating={book.Rating}
                description={book.Description}
                released={book.Released}
                _acl={book._acl}
                deleteBook={this.deleteBook.bind(this)}
            />);
        }
        return rows;
    }

    deleteBook(id) {

        this.setState({
            currentIdForDeletion: id,

        })
        this.toggleDialog();
    }
}