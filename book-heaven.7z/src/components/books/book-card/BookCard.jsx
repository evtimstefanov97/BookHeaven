import React, { Component } from 'react';

export default class BookCard extends Component {
    constructor(props) {
        super(props);

    }
    render() {
        const { name, author, _id, key, rating, description, released, _acl } = this.props;
        return (

            <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3 card">
                <div className="thumbnail">
                    <div className="caption">
                        <h3 className="bookTitle">
                            {name}
                            <small>Author: {author}</small>
                        </h3>
                        <hr />
                        <p className="max-lines">
                            {description}
                        </p>
                        <hr />
                        <p style={{ height: "40px" }}>
                            <b>Released</b>: {released}
                        </p>
                        <hr />
                        <p>
                            <b>Rating</b>: {rating}
                        </p>
                        {_acl["creator"] == localStorage.getItem('username') || localStorage.getItem('admin') == 'true' ?
                            <button type="button" className="close" aria-label="Close" onClick={this.deleteBook.bind(this, _id)}>
                                <span aria-hidden="true">&times;</span>
                            </button>
                            : null
                        }

                    </div>
                </div>
            </div >

        );
    }
    deleteBook(id) {
        this.props.deleteBook(id);
    }
}