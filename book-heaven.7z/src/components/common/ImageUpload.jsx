import React, { Component } from 'react';


export default class ImageUpload extends Component {
    constructor(props) {
        super(props);
        this.state = {
            file: '',
            imagePreviewUrl: '',
            showUploadControl: true

        }
    }

    render() {
        const { imagePreviewUrl } = this.state;
        let imagePreview = null;
        if (imagePreviewUrl) {
            imagePreview = (
                <span>
                    <img src={imagePreviewUrl} />
                    <p style={{ cursor: "pointer", color: 'red', fontWeight: '600' }} onClick={this.removeImage.bind(this)}>X</p>
                </span>

            )
        }
        return (
            <div>
                {imagePreview}

                {this.state.showUploadControl && <input type="file" onChange={this.handleImageChange.bind(this)} accept="image/x-png,image/gif,image/jpeg" />}
            </div>

        );
    }
    handleSubmit(e) {
        e.preventDefault();
    }
    removeImage() {
        this.setState({
            file: '',
            imagePreviewUrl: '',
            showUploadControl: true
        })
    }
    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        if (file) {
            reader.onloadend = () => {
                this.setState({
                    file: file,
                    imagePreviewUrl: reader.result,
                    showUploadControl: false

                })

                this.props.file(this.state.file);
            }
            reader.readAsDataURL(file);
        } else {
            return
        }
    }
}