import React, { Component } from 'react';


export default class TextArea extends Component {
    render() {
        const { name, value, onChange, label } = this.props;
        return (
            <div className="form-group  mx-sm-3 mb-2">
                <label htmlFor={name}>{label}</label>
                <textarea
                    className="form-control"
                    onChange={onChange}
                    name={name}
                    id={name}
                    value={value}
                    maxLength={200}
                    rows={5}
                    style={{ overflow: "auto", resize: "none" }}
                />
            </div>
        );
    }
}